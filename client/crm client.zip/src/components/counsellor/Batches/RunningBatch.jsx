import React, { useEffect, useMemo } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getBatches } from '../../../store/slices/batchSlice';

const RunningBatch = () => {
  const dispatch = useDispatch();
  const { batches = [], loading, error } = useSelector((state) => state.batch || {});

  useEffect(() => {
    dispatch(getBatches({ status: 'Running' }));
  }, [dispatch]);

  const tableRows = useMemo(() => {
    return (batches || []).map((batch, index) => (
      <tr
        key={batch._id || index}
        className={`transition duration-150 ease-in-out ${index % 2 === 0 ? 'bg-white' : 'bg-gray-50'} hover:bg-indigo-50`}
      >
        <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-gray-900">
          {batch.name || 'N/A'}
        </td>
        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
          {batch.course || 'N/A'}
        </td>
        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
          {batch.trainer || 'N/A'}
        </td>
        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
          {batch.branch || 'N/A'}
        </td>
        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
          {batch.code || 'N/A'}
        </td>
        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
          {batch.timing || 'N/A'}
        </td>
        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
          {batch.mode || 'N/A'}
        </td>
        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
          {batch.classRoom || 'N/A'}
        </td>
        <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-blue-700">
          {batch.startDate ? new Date(batch.startDate).toLocaleDateString() : 'N/A'}
        </td>
        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
          {batch.endDate ? new Date(batch.endDate).toLocaleDateString() : 'N/A'}
        </td>
        <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-indigo-600 text-center">
          {batch.studentsActive || 0}
        </td>
      </tr>
    ));
  }, [batches]);

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="flex flex-col items-center">
          <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-indigo-600"></div>
          <p className="mt-4 text-lg text-gray-600">Loading running batches...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border-l-4 border-red-500 text-red-700 p-4 rounded-md mx-6 my-4 shadow-sm" role="alert">
        <p className="font-bold">🚨 Data Fetch Error</p>
        <p>Could not load Running batches. Please check the network or try again. Details: {String(error)}</p>
      </div>
    );
  }

  return (
    <div className="p-6 bg-white">
      <div className="overflow-x-auto shadow-lg rounded-lg border border-gray-200">
        <table className="w-full divide-y divide-gray-200">
          <thead className="bg-red-600">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-bold text-white uppercase tracking-wider">
                Name
              </th>
              <th className="px-6 py-3 text-left text-xs font-bold text-white uppercase tracking-wider">
                Course
              </th>
              <th className="px-6 py-3 text-left text-xs font-bold text-white uppercase tracking-wider">
                Trainer
              </th>
              <th className="px-6 py-3 text-left text-xs font-bold text-white uppercase tracking-wider">
                Branch
              </th>
              <th className="px-6 py-3 text-left text-xs font-bold text-white uppercase tracking-wider">
                Code
              </th>
              <th className="px-6 py-3 text-left text-xs font-bold text-white uppercase tracking-wider">
                Timing
              </th>
              <th className="px-6 py-3 text-left text-xs font-bold text-white uppercase tracking-wider">
                Mode
              </th>
              <th className="px-6 py-3 text-left text-xs font-bold text-white uppercase tracking-wider">
                Class Room
              </th>
              <th className="px-6 py-3 text-left text-xs font-bold text-white uppercase tracking-wider">
                Start Date
              </th>
              <th className="px-6 py-3 text-left text-xs font-bold text-white uppercase tracking-wider">
                End Date
              </th>
              <th className="px-6 py-3 text-center text-xs font-bold text-white uppercase tracking-wider">
                Total
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-100">
            {batches.length === 0 ? (
              <tr>
                <td colSpan="11" className="px-6 py-8 text-center text-gray-500">
                  No running batches found
                </td>
              </tr>
            ) : (
              tableRows
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default RunningBatch;
