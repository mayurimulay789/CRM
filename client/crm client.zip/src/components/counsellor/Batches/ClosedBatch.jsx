import React, { useEffect, useMemo } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getBatches } from '../../../store/slices/batchSlice';

const ClosedBatch = () => {
  const dispatch = useDispatch();
  const { batches = [], loading, error } = useSelector((state) => state.batch || {});

  useEffect(() => {
    dispatch(getBatches({ status: 'Closed' }));
  }, [dispatch]);

  const tableRows = useMemo(() => {
    return batches.map((batch, index) => (
      <tr
        key={batch._id || index}
        className={`transition duration-150 ease-in-out ${index % 2 === 0 ? 'bg-white' : 'bg-gray-50'} hover:bg-indigo-50`}
      >
        <td className="px-6 py-4 whitespace-nowrap">
          <div className="text-sm font-semibold text-gray-900">{batch.name}</div>
        </td>
        <td className="px-6 py-4 max-w-[200px] truncate">
          <div className="text-sm text-gray-600" title={batch.description}>{batch.description || 'N/A'}</div>
        </td>
        <td className="px-6 py-4 whitespace-nowrap">
          <div className="text-sm text-gray-900">{batch.course || 'N/A'}</div>
        </td>
        <td className="px-6 py-4 whitespace-nowrap">
          <div className="text-sm text-gray-900">{batch.trainer || 'N/A'}</div>
        </td>
        <td className="px-6 py-4 whitespace-nowrap">
          <div className="text-sm text-gray-900">{batch.branch || 'N/A'}</div>
        </td>
        <td className="px-6 py-4 whitespace-nowrap">
          <div className="text-sm text-gray-900">{batch.classRoom || 'N/A'}</div>
        </td>
        <td className="px-6 py-4 whitespace-nowrap">
          <div className="text-sm font-mono text-indigo-700">{batch.code || 'N/A'}</div>
        </td>
        <td className="px-6 py-4 whitespace-nowrap">
          <div className="text-sm text-gray-900">{batch.timing || 'N/A'}</div>
        </td>
        <td className="px-6 py-4 whitespace-nowrap">
          <div className="text-sm text-gray-900">{batch.mode || 'N/A'}</div>
        </td>
        <td className="px-6 py-4 whitespace-nowrap">
          <div className="text-sm text-gray-900">{batch.country || 'N/A'}</div>
        </td>
        <td className="px-6 py-4 whitespace-nowrap">
          <div className="text-sm text-gray-900">{batch.batchType || 'N/A'}</div>
        </td>
        <td className="px-6 py-4 whitespace-nowrap text-center">
          <div className="text-sm font-bold text-indigo-600">{batch.studentsActive || 0}</div>
        </td>
        <td className="px-6 py-4 whitespace-nowrap">
          <div className="text-sm text-gray-900">{batch.batchDays || 'N/A'}</div>
        </td>
        <td className="px-6 py-4 whitespace-nowrap">
          <div className="text-sm text-gray-600">
            {batch.startDate ? new Date(batch.startDate).toLocaleDateString() : 'N/A'}
          </div>
        </td>
        <td className="px-6 py-4 whitespace-nowrap">
          <div className="text-sm text-gray-600">
            {batch.endDate ? new Date(batch.endDate).toLocaleDateString() : 'N/A'}
          </div>
        </td>
        <td className="px-6 py-4 whitespace-nowrap">
          <div className="text-sm font-semibold text-green-700">
            {batch.completionDate ? new Date(batch.completionDate).toLocaleDateString() : 'N/A'}
          </div>
        </td>
        <td className="px-6 py-4 whitespace-nowrap">
          <div className="text-sm text-gray-900">{batch.mergingStatus || 'N/A'}</div>
        </td>
        <td className="px-6 py-4 whitespace-nowrap">
          <div className="text-sm text-gray-600">
            {batch.mergingTill ? new Date(batch.mergingTill).toLocaleDateString() : 'N/A'}
          </div>
        </td>
        <td className="px-6 py-4 whitespace-nowrap">
          <div className="text-sm text-gray-900">{batch.batchExtenApproval || 'N/A'}</div>
        </td>
        <td className="px-6 py-4 whitespace-nowrap">
          <div className="text-sm text-gray-900">{batch.approvalStatus || 'N/A'}</div>
        </td>
        <td className="px-6 py-4 whitespace-nowrap">
          <span className="inline-flex items-center px-3 py-1 text-xs font-bold leading-5 rounded-full bg-green-100 text-green-800 border border-green-300">
            <span className="w-2 h-2 mr-2 bg-green-500 rounded-full"></span>
            Closed
          </span>
        </td>
      </tr>
    ));
  }, [batches]);

    if (loading) {
      return (
        <div className="flex justify-center items-center min-h-[400px]">
          <div className="flex flex-col items-center">
            <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-indigo-600"></div>
            <p className="mt-4 text-lg text-gray-600">Loading closed batches...</p>
          </div>
        </div>
      );
    }
  
    if (error) {
      return (
        <div className="bg-red-50 border-l-4 border-red-500 text-red-700 p-4 rounded-md mx-6 my-4 shadow-sm" role="alert">
          <p className="font-bold">🚨 Data Fetch Error</p>
          <p>Could not load Closed batches. Please check the network or try again. Details: {String(error)}</p>
        </div>
      );
    }
  
    return (
      <div className="p-4 sm:p-6 lg:p-8 bg-gray-50 min-h-screen">
        <h1 className="text-3xl sm:text-4xl font-extrabold text-gray-900 mb-6 border-b-4 border-indigo-600 pb-2 inline-block">
          <span className="mr-3 text-indigo-600">✅</span> Completed Batches
        </h1>
  
        {batches.length === 0 ? (
          <div className="text-center bg-white p-16 rounded-xl shadow-lg border border-gray-200 mt-8">
            <div className="text-8xl mb-4 text-gray-400">📦</div>
            <p className="text-2xl font-semibold text-gray-700">No Closed Batches Found</p>
            <p className="mt-2 text-gray-500">There are no completed or closed batches to display at this time.</p>
          </div>
        ) : (
          <div className="mt-8">
            <div className="overflow-x-auto shadow-2xl rounded-xl border border-gray-200">
              <table className="min-w-max divide-y divide-gray-200 w-full">
                <thead className="bg-indigo-700 sticky top-0 z-10">
                  <tr>
                    {[
                      'Batch Name', 'Description', 'Course', 'Trainer', 'Branch',
                      'Class Room', 'Code', 'Timing', 'Mode', 'Country',
                      'Batch Type', 'Students', 'Batch Days', 'Start Date', 'End Date',
                      'Completion Date', 'Merging Status', 'Merging Till',
                      'Exten Approval', 'Approval Status', 'Status'
                    ].map((header) => (
                      <th key={header} className="px-6 py-3 text-left text-xs font-bold text-white uppercase tracking-wider">{header}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-100">
                  {tableRows}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    );
  };
  
  export default ClosedBatch;